# UARCap v0.6 frozen follow-up transfer

The eight prepared input files and the six required-cache ID lists were copied byte-for-byte from the Windows handoff. See INPUT_FILE_MANIFEST.json for member names, arms, and SHA-256. The full ZIP size and SHA-256 are in the externally distributed GITHUB_INPUT_TRANSFER_MANIFEST.json. The ZIP cannot contain a hash of its own complete bytes.

Run receive_bn_inputs.py from the same pinned GitHub transfer commit. Supply the ZIP, its external manifest, the verified BN test2990/untouched2690 TSV ID manifests, and a fresh writable output directory. Omitting --out verifies without writing. Retain the original member bytes. A1/A7 consume the separate existing frozen FULL D CAP/SIM, not derived copies in this ZIP.

## Attribution

Caption strings and clip identifiers are selected from *VideoUFO: A Million-Scale User-Focused Dataset for Text-to-Video Generation* by Wenhao Wang and Yi Yang. The authors release the dataset under Creative Commons Attribution 4.0 International. UARCap selects, groups and reorders the supplied brief-caption strings, adds the frozen retrieval scores and query IDs, and records the specified text-only tail associations. The selected caption strings were copied from the frozen candidate pool. This package contains no video, image, model weights, or benchmark reference captions.

- VideoUFO dataset card: https://huggingface.co/datasets/WenhaoWang/VideoUFO
- Dataset release statement: https://proceedings.neurips.cc/paper_files/paper/2025/hash/1e6057620ed314b0020b3a30284b0f83-Abstract-Datasets_and_Benchmarks_Track.html
- License: https://creativecommons.org/licenses/by/4.0/
